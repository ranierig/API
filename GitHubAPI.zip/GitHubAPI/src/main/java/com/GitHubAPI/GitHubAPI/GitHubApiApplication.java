package com.GitHubAPI.GitHubAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitHubApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitHubApiApplication.class, args);
	}

}
